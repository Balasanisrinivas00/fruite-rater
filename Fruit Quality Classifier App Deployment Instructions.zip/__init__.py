"""
Models package initialization
"""
