# Fruit Quality Classifier - README

## Project Overview
The Fruit Quality Classifier is a web application that uses computer vision and deep learning to classify fruit images into three quality categories: Good, Average, or Bad. The application features a modern, responsive UI with real-time prediction capabilities, webcam support, and user authentication.

## Features
- **Image Classification**: Upload or capture fruit images to classify their quality
- **Real-time Webcam Capture**: Use your device camera to capture and classify fruits instantly
- **Explainable AI**: View heatmap visualizations showing which parts of the image influenced the classification
- **User Authentication**: Secure login and registration system
- **Prediction History**: View and track your previous classifications
- **Responsive Design**: Works on desktop and mobile devices
- **Modern UI**: Clean, intuitive interface inspired by modern AI applications

## Technology Stack
- **Backend**: Flask (Python)
- **Frontend**: HTML, CSS, JavaScript
- **Machine Learning**: TensorFlow, OpenCV, scikit-learn
- **Authentication**: Flask session-based authentication
- **Data Storage**: File-based JSON storage for user data and prediction history

## Installation and Setup

### Prerequisites
- Python 3.8 or higher
- pip package manager
- Virtual environment (recommended)

### Installation Steps

1. Clone the repository:
```bash
git clone <repository-url>
cd fruit-quality-classifier
```

2. Create and activate a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Run the application:
```bash
cd src
python -c "from main import app; app.run(host='0.0.0.0', debug=True)"
```

5. Access the application:
Open your browser and navigate to `http://localhost:5000`

## Project Structure
```
fruit_quality_classifier/
├── data/                  # Data directory for training and user data
│   ├── fruits/            # Sample fruit images
│   ├── train/             # Training data
│   ├── val/               # Validation data
│   └── users.json         # User data and prediction history
├── models/                # Saved ML models
│   ├── fruit_quality_model.h5  # Trained CNN model
│   └── training_history.png    # Training metrics visualization
├── src/                   # Source code
│   ├── models/            # ML model definitions
│   │   ├── cnn_model.py   # CNN architecture
│   │   └── gradcam.py     # Grad-CAM visualization
│   ├── routes/            # API endpoints
│   │   ├── auth.py        # Authentication routes
│   │   └── prediction.py  # Prediction routes
│   ├── static/            # Static assets
│   │   ├── css/           # Stylesheets
│   │   ├── js/            # JavaScript files
│   │   └── img/           # Images and icons
│   ├── templates/         # HTML templates
│   │   └── index.html     # Main application template
│   └── main.py            # Application entry point
└── requirements.txt       # Python dependencies
```

## API Endpoints

### Authentication
- `POST /api/auth/register`: Register a new user
- `POST /api/auth/login`: Log in a user
- `POST /api/auth/logout`: Log out a user
- `GET /api/auth/user`: Get current user information
- `GET /api/auth/history`: Get user prediction history

### Prediction
- `POST /api/prediction/predict`: Predict fruit quality from uploaded image or base64 image data
- `POST /api/prediction/webcam_predict`: Predict fruit quality from webcam image

## Model Training

The application includes a pre-trained CNN model for fruit quality classification. To retrain the model with your own data:

1. Organize your fruit images in the following structure:
```
data/
├── train/
│   ├── good/
│   │   └── [good quality fruit images]
│   ├── average/
│   │   └── [average quality fruit images]
│   └── bad/
│       └── [bad quality fruit images]
└── val/
    ├── good/
    │   └── [good quality fruit images for validation]
    ├── average/
    │   └── [average quality fruit images for validation]
    └── bad/
        └── [bad quality fruit images for validation]
```

2. Run the training script:
```bash
python src/train.py --data_dir data --model_dir models --transfer_learning
```

Options:
- `--data_dir`: Directory containing the dataset
- `--model_dir`: Directory to save the model
- `--img_size`: Input image size (default: 100)
- `--batch_size`: Training batch size (default: 32)
- `--epochs`: Number of training epochs (default: 20)
- `--transfer_learning`: Use transfer learning with MobileNetV2
- `--create_samples`: Create sample data for testing

## Deployment

The application can be deployed to various cloud platforms:

### Heroku
1. Create a Procfile:
```
web: gunicorn -w 4 -b 0.0.0.0:$PORT src.main:app
```

2. Add gunicorn to requirements.txt
3. Deploy to Heroku:
```bash
heroku create fruit-quality-classifier
git push heroku main
```

### AWS, GCP, or Azure
Follow the platform-specific instructions for deploying Flask applications.

## License
[MIT License](LICENSE)

## Acknowledgements
- TensorFlow and Keras for the deep learning framework
- Flask for the web framework
- OpenCV for image processing
- The open-source community for various libraries and tools
